BOT KICK V1.0

Fungsinya cuman 4 :
- Cek Speed Bot
- Kick semua member
- NgeTag semua member ( Beta )
- Spam lagu JKT48 - oogoe diamond

Keyword :
- Salken All = Buat test kecepatan Bot
- Mulai = Buat mulai ngekick member satu per satu
- Tagall = Tag semua member ( Beta )
- Spam = Spam lirik lagu JKT48 - oogoe diamond

Created By Farzain - zFz
